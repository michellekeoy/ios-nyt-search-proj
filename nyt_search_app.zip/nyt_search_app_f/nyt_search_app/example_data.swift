//
//{
//    copyright = "Copyright (c) 2020 The New York Times Company. All Rights Reserved.";
//    response =     {
//        docs =         (
//            {
//            "_id" = "nyt://interactive/b87fb62a-3288-5f17-9f3d-f493425b08f1";
//                abstract = "Everyone, it seems, has an opinion on the best way to make yogurt.";
//                byline =                 {
//                    organization = "The New York Times";
//                    original = "By THE NEW YORK TIMES";
//                    person =                     (
//                    );
//                };
//                "document_type" = multimedia;
//                headline =                 {
//                    "content_kicker" = "<null>";
//                    kicker = "<null>";
//                    main = "Yogurt-Making Tips From Readers";
//                    name = "<null>";
//                    "print_headline" = "<null>";
//                    seo = "<null>";
//                    sub = "<null>";
//                };
//                keywords =                 (
//                                        {
//                        major = N;
//                        name = subject;
//                        rank = 1;
//                        value = Yogurt;
//                    },
//                                        {
//                        major = N;
//                        name = subject;
//                        rank = 2;
//                        value = "Cooking and Cookbooks";
//                    }
//                );
//                "lead_paragraph" = "Everyone, it seems, has an opinion on the best way to make yogurt.";
//                multimedia =                 (
//                                        {
//                        caption = "<null>";
//                        credit = "<null>";
//                        "crop_name" = watch308;
//                        height = 348;
//                        legacy =                         {
//                        };
//                        rank = 0;
//                        subType = watch308;
//                        subtype = watch308;
//                        type = image;
//                        url = "images/2016/02/24/dining/24APPE2/24APPE2-watch308.jpg";
//                        width = 312;
//                    },
//                           {
//                        caption = "<null>";
//                        credit = "<null>";
//                        "crop_name" = smallSquare168;
//                        height = 168;
//                        legacy =                         {
//                        };
//                        rank = 0;
//                        subType = smallSquare168;
//                        subtype = smallSquare168;
//                        type = image;
//                        url = "images/2016/02/24/dining/24APPE2/24APPE2-smallSquare168.jpg";
//                        width = 168;
//                    }
//                );
//                "news_desk" = Food;
//                "pub_date" = "2016-02-25T21:46:12+0000";
//                "section_name" = Food;
//                snippet = "Everyone, it seems, has an opinion on the best way to make yogurt.";
//                source = "The New York Times";
//                "type_of_material" = "Interactive Feature";
//                uri = "nyt://interactive/b87fb62a-3288-5f17-9f3d-f493425b08f1";
//                "web_url" = "https://www.nytimes.com/interactive/2016/02/25/dining/how-to-make-yogurt-tips.html";
//                "word_count" = 0;
//            },
//                        {
//                "_id" = "nyt://interactive/661d788b-233a-5058-9751-e6e1c6d8995c";
//                abstract = "Can Sandra Day O\U2019Connor be renominated? Can Mitch McConnell be impeached? In our insiders\U2019 guide, Times reporters offer answers.";
//                byline =                 {
//                    organization = "<null>";
//                    original = "<null>";
//                    person =                     (
//                    );
//                };
//                "document_type" = multimedia;
//                headline =                 {
//                    "content_kicker" = "<null>";
//                    kicker = "<null>";
//                    main = "Battle for the Supreme Court: Can Obama Sue Congress Over Nomination Fight?";
//                    name = "<null>";
//                    "print_headline" = "<null>";
//                    seo = "<null>";
//                    sub = "<null>";
//                };
//                keywords =                 (
//                                        {
//                        major = N;
//                        name = organizations;
//                        rank = 1;
//                        value = "Supreme Court (US)";
//                    },
//                                        {
//                        major = N;
//                        name = subject;
//                        rank = 2;
//                        value = "Courts and the Judiciary";
//                    },
//                                        {
//                        major = N;
//                        name = persons;
//                        rank = 3;
//                        value = "McConnell, Mitch";
//                    },
//                                        {
//                        major = N;
//                        name = persons;
//                        rank = 4;
//                        value = "Obama, Barack";
//                    }
//                );
//                "lead_paragraph" = "Can Sandra Day O\U2019Connor be renominated? Can Mitch McConnell be impeached? In our insiders\U2019 guide, Times reporters offer answers.";
//                multimedia =                 (
//                                        {
//                        caption = "<null>";
//                        credit = "<null>";
//                        "crop_name" = watch308;
//                        height = 348;
//                        legacy =                         {
//                        };
//                        rank = 0;
//                        subType = watch308;
//                        subtype = watch308;
//                        type = image;
//                        url = "images/2016/02/26/us/27BATTLE-web3/27BATTLE-web3-watch308.jpg";
//                        width = 312;
//                    },
//                                        {
//                        caption = "<null>";
//                        credit = "<null>";
//                        "crop_name" = watch268;
//                        height = 303;
//                        legacy =                         {
//                        };
//                        rank = 0;
//                        subType = watch268;
//                        subtype = watch268;
//                        type = image;
//                        url = "images/2016/02/26/us/27BATTLE-web3/27BATTLE-web3-watch268.jpg";
//                        width = 272;
//                    },
//                );
//                "news_desk" = "U.S.";
//                "pub_date" = "2016-02-26T11:21:44+0000";
//                "section_name" = "U.S.";
//                snippet = "Can Sandra Day O\U2019Connor be renominated? Can Mitch McConnell be impeached? In our insiders\U2019 guide, Times reporters offer answers.";
//                source = "The New York Times";
//                "subsection_name" = Politics;
//                "type_of_material" = "Interactive Feature";
//                uri = "nyt://interactive/661d788b-233a-5058-9751-e6e1c6d8995c";
//                "web_url" = "https://www.nytimes.com/interactive/2016/02/26/us/politics/battle-for-the-supreme-court-reader-questions-answered.html";
//                "word_count" = 0;
//            },
//                        {
//                "_id" = "nyt://interactive/54de864b-ad05-5319-acc7-96cca835c4ed";
//                abstract = "Information on sales in New York, New Jersey and Connecticut.";
//                byline =                 {
//                    organization = "<null>";
//                    original = "<null>";
//                    person =                     (
//                    );
//                };
//                "document_type" = multimedia;
//                headline =                 {
//                    "content_kicker" = "<null>";
//                    kicker = "<null>";
//                    main = "Home Sales Around the New York Region";
//                    name = "<null>";
//                    "print_headline" = "<null>";
//                    seo = "<null>";
//                    sub = "<null>";
//                };
//                keywords =                 (
//                                        {
//                        major = N;
//                        name = subject;
//                        rank = 1;
//                        value = "Real Estate and Housing (Residential)";
//                    },
//                                        {
//                        major = N;
//                        name = glocations;
//                        rank = 2;
//                        value = "New York City";
//                    },
//                                        {
//                        major = N;
//                        name = glocations;
//                        rank = 3;
//                        value = "Westchester County (NY)";
//                    },
//                                        {
//                        major = N;
//                        name = glocations;
//                        rank = 4;
//                        value = "New Jersey";
//                    },
//                                        {
//                        major = N;
//                        name = glocations;
//                        rank = 5;
//                        value = Connecticut;
//                    }
//                );
//                "lead_paragraph" = "Information on sales in New York, New Jersey and Connecticut.";
//                multimedia =                 (
//                                        {
//                        caption = "<null>";
//                        credit = "<null>";
//                        "crop_name" = watch308;
//                        height = 348;
//                        legacy =                         {
//                        };
//                        rank = 0;
//                        subType = watch308;
//                        subtype = watch308;
//                        type = image;
//                        url = "images/2016/02/28/realestate/28matrix/28matrix-watch308.jpg";
//                        width = 312;
//                    },
//
//                                        {
//                        caption = "<null>";
//                        credit = "<null>";
//                        "crop_name" = smallSquare168;
//                        height = 168;
//                        legacy =                         {
//                        };
//                        rank = 0;
//                        subType = smallSquare168;
//                        subtype = smallSquare168;
//                        type = image;
//                        url = "images/2016/02/28/realestate/28matrix/28matrix-smallSquare168.jpg";
//                        width = 168;
//                    }
//                );
//                "news_desk" = "Real Estate";
//                "pub_date" = "2016-02-26T18:08:58+0000";
//                "section_name" = "Real Estate";
//                snippet = "Information on sales in New York, New Jersey and Connecticut.";
//                source = "The New York Times";
//                "type_of_material" = "Interactive Feature";
//                uri = "nyt://interactive/54de864b-ad05-5319-acc7-96cca835c4ed";
//                "web_url" = "https://www.nytimes.com/interactive/2016/02/28/realestate/28Real-Estate-Matrix-Graphic.html";
//                "word_count" = 0;
//            },
//                        {
//                "_id" = "nyt://interactive/ea7b86be-7823-5537-80e8-c912d3657b7e";
//                abstract = "Dallas Keuchel of the Houston Astros dominated the Yankees last year, defeating them three times. We take a closer look at those games as well as a list of other pitchers who have managed to confound the Yankees.";
//                byline =                 {
//                    organization = "<null>";
//                    original = "<null>";
//                    person =                     (
//                    );
//                };
//                "document_type" = multimedia;
//                headline =                 {
//                    "content_kicker" = "<null>";
//                    kicker = "<null>";
//                    main = "Baffling the Yankees: A Select Group";
//                    name = "<null>";
//                    "print_headline" = "<null>";
//                    seo = "<null>";
//                    sub = "<null>";
//                };
//                keywords =                 (
//                                        {
//                        major = N;
//                        name = subject;
//                        rank = 1;
//                        value = Baseball;
//                    },
//                                        {
//                        major = N;
//                        name = organizations;
//                        rank = 2;
//                        value = "New York Yankees";
//                    },
//                                        {
//                        major = N;
//                        name = persons;
//                        rank = 3;
//                        value = "Keuchel, Dallas";
//                    }
//                );
//                "lead_paragraph" = "Dallas Keuchel of the Houston Astros dominated the Yankees last year, defeating them three times. We take a closer look at those games as well as a list of other pitchers who have managed to confound the Yankees.";
//                multimedia =                 (
//                                        {
//                        caption = "<null>";
//                        credit = "<null>";
//                        "crop_name" = watch308;
//                        height = 348;
//                        legacy =                         {
//                        };
//                        rank = 0;
//                        subType = watch308;
//                        subtype = watch308;
//                        type = image;
//                        url = "images/2016/02/27/sports/kepner-grafic-promo-photo/kepner-grafic-promo-photo-watch308.jpg";
//                        width = 312;
//                    },
//                              {
//                        caption = "<null>";
//                        credit = "<null>";
//                        "crop_name" = smallSquare168;
//                        height = 168;
//                        legacy =                         {
//                        };
//                        rank = 0;
//                        subType = smallSquare168;
//                        subtype = smallSquare168;
//                        type = image;
//                        url = "images/2016/02/27/sports/kepner-grafic-promo-photo/kepner-grafic-promo-photo-smallSquare168.jpg";
//                        width = 168;
//                    }
//                );
//                "news_desk" = Sports;
//                "pub_date" = "2016-02-27T21:49:01+0000";
//                "section_name" = Sports;
//                snippet = "Dallas Keuchel of the Houston Astros dominated the Yankees last year, defeating them three times. We take a closer look at those games as well as a list of other pitchers who have managed to confound the Yankees.";
//                source = "The New York Times";
//                "subsection_name" = Baseball;
//                "type_of_material" = "Interactive Feature";
//                uri = "nyt://interactive/ea7b86be-7823-5537-80e8-c912d3657b7e";
//                "web_url" = "https://www.nytimes.com/interactive/2016/02/28/sports/baseball/baffling-the-yankees.html";
//                "word_count" = 0;
//            },
//                        {
//                "_id" = "nyt://interactive/829f125d-6936-5c1a-9bd9-7f9fcc42f015";
//                abstract = "A playlist by the writers Marlon James, Jenna Wortham, George Saunders, Wesley Morris, Mary H. K. Choi and others.";
//                byline =                 {
//                    organization = "The New York Times";
//                    original = "By THE NEW YORK TIMES MAGAZINE";
//                    person =                     (
//                    );
//                };
//                "document_type" = multimedia;
//                headline =                 {
//                    "content_kicker" = "<null>";
//                    kicker = "The Music Issue";
//                    main = "25 Songs That Tell Us Where Music Is Going";
//                    name = "<null>";
//                    "print_headline" = "<null>";
//                    seo = "<null>";
//                    sub = "<null>";
//                };
//                keywords =                 (
//                                        {
//                        major = N;
//                        name = subject;
//                        rank = 1;
//                        value = Music;
//                    },
//
//                                        {
//                        major = N;
//                        name = persons;
//                        rank = 6;
//                        value = "Bowie, David";
//                    }
//                );
//                "lead_paragraph" = "A playlist by the writers Marlon James, Jenna Wortham, George Saunders, Wesley Morris, Mary H. K. Choi and others.";
//                multimedia =                 (
//                                        {
//                        caption = "<null>";
//                        credit = "<null>";
//                        "crop_name" = watch308;
//                        height = 348;
//                        legacy =                         {
//                        };
//                        rank = 0;
//                        subType = watch308;
//                        subtype = watch308;
//                        type = image;
//                        url = "images/2016/03/13/magazine/13mag-music-promo/13mag-music-promo-watch308.png";
//                        width = 312;
//                    },
//                                        {
//                        caption = "<null>";
//                        credit = "<null>";
//                        "crop_name" = watch268;
//                        height = 303;
//                        legacy =                         {
//                        };
//                        rank = 0;
//                        subType = watch268;
//                        subtype = watch268;
//                        type = image;
//                        url = "images/2016/03/13/magazine/13mag-music-promo/13mag-music-promo-watch268.png";
//                        width = 272;
//                    },
//                                          {
//                        caption = "<null>";
//                        credit = "<null>";
//                        "crop_name" = smallSquare168;
//                        height = 168;
//                        legacy =                         {
//                        };
//                        rank = 0;
//                        subType = smallSquare168;
//                        subtype = smallSquare168;
//                        type = image;
//                        url = "images/2016/03/13/magazine/13mag-music-promo/13mag-music-promo-smallSquare168.png";
//                        width = 168;
//                    }
//                );
//                "news_desk" = Magazine;
//                "pub_date" = "2016-03-10T13:29:39+0000";
//                "section_name" = Magazine;
//                snippet = "A playlist by the writers Marlon James, Jenna Wortham, George Saunders, Wesley Morris, Mary H. K. Choi and others.";
//                source = "The New York Times";
//                "type_of_material" = "Interactive Feature";
//                uri = "nyt://interactive/829f125d-6936-5c1a-9bd9-7f9fcc42f015";
//                "web_url" = "https://www.nytimes.com/interactive/2016/03/10/magazine/25-songs-that-tell-us-where-music-is-going.html";
//                "word_count" = 0;
//            },
//                        {
//                "_id" = "nyt://interactive/446cb8d4-300d-5e8b-9396-4792afb7abbc";
//                abstract = "Read key findings from the investigative series and watch the film \U201cThe Fantasy Sports Gamble.\U201d";
//                byline =                 {
//                    organization = "The New York Times";
//                    original = "By THE NEW YORK TIMES";
//                    person =                     (
//                    );
//                };
//                "document_type" = multimedia;
//                headline =                 {
//                    "content_kicker" = "<null>";
//                    kicker = "Wired for Profit";
//                    main = "Watch the \U2018Frontline\U2019 and Times Documentary on Fantasy Sports and Online Gambling";
//                    name = "<null>";
//                    "print_headline" = "<null>";
//                    seo = "<null>";
//                    sub = "<null>";
//                };
//                keywords =                 (
//                                        {
//                        major = N;
//                        name = subject;
//                        rank = 1;
//                        value = "Fantasy Sports";
//                    }
//                                        {
//                        major = N;
//                        name = persons;
//                        rank = 6;
//                        value = "Schneiderman, Eric T";
//                    },
//                                        {
//                        major = N;
//                        name = subject;
//                        rank = 7;
//                        value = "Addiction (Psychology)";
//                    },
//                                        {
//                        major = N;
//                        name = subject;
//                        rank = 8;
//                        value = "Computers and the Internet";
//                    }
//                );
//                "lead_paragraph" = "Read key findings from the investigative series and watch the film \U201cThe Fantasy Sports Gamble.\U201d";
//                multimedia =                 (
//                                        {
//                        caption = "<null>";
//                        credit = "<null>";
//                        "crop_name" = watch308;
//                        height = 348;
//                        legacy =                         {
//                        };
//                        rank = 0;
//                        subType = watch308;
//                        subtype = watch308;
//                        type = image;
//                        url = "images/2016/02/01/multimedia/frontline-gambling-trlr2/frontline-gambling-trlr2-watch308.jpg";
//                        width = 312;
//                    },
//
//                                        {
//                        caption = "<null>";
//                        credit = "<null>";
//                        "crop_name" = smallSquare168;
//                        height = 168;
//                        legacy =                         {
//                        };
//                        rank = 0;
//                        subType = smallSquare168;
//                        subtype = smallSquare168;
//                        type = image;
//                        url = "images/2016/02/01/multimedia/frontline-gambling-trlr2/frontline-gambling-trlr2-smallSquare168.jpg";
//                        width = 168;
//                    }
//                );
//                "news_desk" = Sports;
//                "pub_date" = "2016-02-09T11:00:09+0000";
//                "section_name" = Sports;
//                snippet = "Read key findings from the investigative series and watch the film \U201cThe Fantasy Sports Gamble.\U201d";
//                source = "The New York Times";
//                "type_of_material" = "Interactive Feature";
//                uri = "nyt://interactive/446cb8d4-300d-5e8b-9396-4792afb7abbc";
//                "web_url" = "https://www.nytimes.com/interactive/2016/02/09/sports/fantasy-sports-betting-fanduel-draftkings-frontline.html";
//                "word_count" = 0;
//            },
//                        {
//                "_id" = "nyt://interactive/ec61ec74-951d-5b26-86d8-062729d39424";
//                abstract = "Matthew Thomas\U2019s \U201cWe Are Not Ourselves,\U201d a multi-generational saga of Irish immigrant life in New York, was the subject of an online discussion on Feb. 11, 2016.";
//                byline =                 {
//                    organization = "<null>";
//                    original = "<null>";
//                    person =                     (
//                    );
//                };
//                "document_type" = multimedia;
//                headline =                 {
//                    "content_kicker" = "<null>";
//                    kicker = "<null>";
//                    main = "Big City Book Club";
//                    name = "<null>";
//                    "print_headline" = "<null>";
//                    seo = "<null>";
//                    sub = "<null>";
//                };
//                keywords =                 (
//                                        {
//                        major = N;
//                        name = subject;
//                        rank = 1;
//                        value = "Book Clubs";
//                    }
//                );
//                "lead_paragraph" = "Matthew Thomas\U2019s \U201cWe Are Not Ourselves,\U201d a multi-generational saga of Irish immigrant life in New York, was the subject of an online discussion on Feb. 11, 2016.";
//                multimedia =                 (
//                                        {
//                        caption = "<null>";
//                        credit = "<null>";
//                        "crop_name" = watch308;
//                        height = 348;
//                        legacy =                         {
//                        };
//                        rank = 0;
//                        subType = watch308;
//                        subtype = watch308;
//                        type = image;
//                        url = "images/2016/01/10/nyregion/10CLUB1SUB/10CLUB1SUB-watch308-v2.jpg";
//                        width = 312;
//                    },
//                                        {
//                        caption = "<null>";
//                        credit = "<null>";
//                        "crop_name" = watch268;
//                        height = 303;
//                        legacy =                         {
//                        };
//                        rank = 0;
//                        subType = watch268;
//                        subtype = watch268;
//                        type = image;
//                        url = "images/2016/01/10/nyregion/10CLUB1SUB/10CLUB1SUB-watch268-v2.jpg";
//                        width = 272;
//                    },
//                                        {
//                        caption = "<null>";
//                        credit = "<null>";
//                        "crop_name" = smallSquare168;
//                        height = 168;
//                        legacy =                         {
//                        };
//                        rank = 0;
//                        subType = smallSquare168;
//                        subtype = smallSquare168;
//                        type = image;
//                        url = "images/2016/01/10/nyregion/10CLUB1SUB/10CLUB1SUB-smallSquare168.jpg";
//                        width = 168;
//                    }
//                );
//                "news_desk" = "New York";
//                "pub_date" = "2016-02-10T19:11:29+0000";
//                "section_name" = "New York";
//                snippet = "Matthew Thomas\U2019s \U201cWe Are Not Ourselves,\U201d a multi-generational saga of Irish immigrant life in New York, was the subject of an online discussion on Feb. 11, 2016.";
//                source = "The New York Times";
//                "type_of_material" = "Interactive Feature";
//                uri = "nyt://interactive/ec61ec74-951d-5b26-86d8-062729d39424";
//                "web_url" = "https://www.nytimes.com/interactive/2016/02/11/nyregion/big-city-book-club-we-are-not-ourselves-matthew-thomas.html";
//                "word_count" = 0;
//            },
//                        {
//                "_id" = "nyt://interactive/9641a038-38eb-5925-8827-ccc84e476a64";
//                abstract = "Scarlett Johansson and Mich\U00e8le Lamy try some new products.";
//                byline =                 {
//                    organization = "<null>";
//                    original = "<null>";
//                    person =                     (
//                    );
//                };
//                "document_type" = multimedia;
//                headline =                 {
//                    "content_kicker" = "<null>";
//                    kicker = "<null>";
//                    main = "Take Two: Scarlett Johansson and Mich\U00e8le Lamy";
//                    name = "<null>";
//                    "print_headline" = "<null>";
//                    seo = "<null>";
//                    sub = "<null>";
//                };
//                keywords =                 (
//                                        {
//                        major = N;
//                        name = persons;
//                        rank = 1;
//                        value = "Johansson, Scarlett";
//                    }
//                );
//                "lead_paragraph" = "Scarlett Johansson and Mich\U00e8le Lamy try some new products.";
//                multimedia =                 (
//                                        {
//                        caption = "<null>";
//                        credit = "<null>";
//                        "crop_name" = watch308;
//                        height = 348;
//                        legacy =                         {
//                        };
//                        rank = 0;
//                        subType = watch308;
//                        subtype = watch308;
//                        type = image;
//                        url = "images/2016/02/08/t-magazine/08taketwo-scarlett/08taketwo-scarlett-watch308.jpg";
//                        width = 312;
//                    },
//                                     {
//                        caption = "<null>";
//                        credit = "<null>";
//                        "crop_name" = smallSquare168;
//                        height = 168;
//                        legacy =                         {
//                        };
//                        rank = 0;
//                        subType = smallSquare168;
//                        subtype = smallSquare168;
//                        type = image;
//                        url = "images/2016/02/08/t-magazine/08taketwo-scarlett/08taketwo-scarlett-smallSquare168.jpg";
//                        width = 168;
//                    }
//                );
//                "news_desk" = "T Magazine";
//                "pub_date" = "2016-02-10T18:50:10+0000";
//                "section_name" = "T Magazine";
//                snippet = "Scarlett Johansson and Mich\U00e8le Lamy try some new products.";
//                source = "The New York Times";
//                "type_of_material" = "Interactive Feature";
//                uri = "nyt://interactive/9641a038-38eb-5925-8827-ccc84e476a64";
//                "web_url" = "https://www.nytimes.com/interactive/2016/02/10/t-magazine/take-two-scarlett-johansson-michele-lamy.html";
//                "word_count" = 0;
//            },
//                        {
//                "_id" = "nyt://interactive/417da559-58fa-5dad-b637-534a2d08efa7";
//                abstract = "Selected by Natasha Trethewey.";
//                byline =                 {
//                    organization = "<null>";
//                    original = "By DAVID KIRBY";
//                    person =                     (
//                                                {
//                            firstname = David;
//                            lastname = KIRBY;
//                            middlename = "<null>";
//                            organization = "";
//                            qualifier = "<null>";
//                            rank = 1;
//                            role = reported;
//                            title = "<null>";
//                        }
//                    );
//                };
//                "document_type" = multimedia;
//                headline =                 {
//                    "content_kicker" = "<null>";
//                    kicker = Poem;
//                    main = "\U2018Taking It Home to Jerome\U2019";
//                    name = "<null>";
//                    "print_headline" = "<null>";
//                    seo = "<null>";
//                    sub = "<null>";
//                };
//                keywords =                 (
//                                        {
//                        major = N;
//                        name = glocations;
//                        rank = 1;
//                        value = "Baton Rouge (La)";
//                    },
//                                        {
//                        major = N;
//                        name = subject;
//                        rank = 2;
//                        value = "Poetry and Poets";
//                    }
//                );
//                "lead_paragraph" = "Selected by Natasha Trethewey.";
//                multimedia =                 (
//                                        {
//                        caption = "<null>";
//                        credit = "<null>";
//                        "crop_name" = watch308;
//                        height = 348;
//                        legacy =                         {
//                        };
//                        rank = 0;
//                        subType = watch308;
//                        subtype = watch308;
//                        type = image;
//                        url = "images/2016/02/14/magazine/14poem/14mag-14poem-t_CA0-watch308.jpg";
//                        width = 312;
//                    },       {
//                        caption = "<null>";
//                        credit = "<null>";
//                        "crop_name" = smallSquare168;
//                        height = 168;
//                        legacy =                         {
//                        };
//                        rank = 0;
//                        subType = smallSquare168;
//                        subtype = smallSquare168;
//                        type = image;
//                        url = "images/2016/02/14/magazine/14poem/14mag-14poem-t_CA0-smallSquare168.jpg";
//                        width = 168;
//                    }
//                );
//                "news_desk" = Magazine;
//                "pub_date" = "2016-02-12T12:00:11+0000";
//                "section_name" = Magazine;
//                snippet = "Selected by Natasha Trethewey.";
//                source = "The New York Times";
//                "type_of_material" = "Interactive Feature";
//                uri = "nyt://interactive/417da559-58fa-5dad-b637-534a2d08efa7";
//                "web_url" = "https://www.nytimes.com/interactive/2016/02/14/magazine/david-kirby-taking-it-home-to-jerome.html";
//                "word_count" = 0;
//            },
//                        {
//                "_id" = "nyt://interactive/06c1330f-77d4-5b0e-827b-64e01c817b97";
//                abstract = "A generation gap is emerging over the importance of electing a woman to the White House. We invite you to share your opinion. The Times may follow up with you.";
//                byline =                 {
//                    organization = "<null>";
//                    original = "<null>";
//                    person =                     (
//                    );
//                };
//                "document_type" = multimedia;
//                headline =                 {
//                    "content_kicker" = "<null>";
//                    kicker = "<null>";
//                    main = "Tell Us: Is It Important to Elect a Woman as President?";
//                    name = "<null>";
//                    "print_headline" = "<null>";
//                    seo = "<null>";
//                    sub = "<null>";
//                };
//                keywords =                 (
//                                        {
//                        major = N;
//                        name = subject;
//                        rank = 1;
//                        value = "United States Politics and Government";
//                    },
//                                        {
//                        major = N;
//                        name = subject;
//                        rank = 2;
//                        value = "Presidential Election of 2016";
//                    },
//                                        {
//                        major = N;
//                        name = subject;
//                        rank = 3;
//                        value = "Women and Girls";
//                    },
//                                        {
//                        major = N;
//                        name = subject;
//                        rank = 4;
//                        value = "Women's Rights";
//                    }
//                );
//                "lead_paragraph" = "A generation gap is emerging over the importance of electing a woman to the White House. We invite you to share your opinion. The Times may follow up with you.";
//                multimedia =                 (
//                                        {
//                        caption = "<null>";
//                        credit = "<null>";
//                        "crop_name" = watch308;
//                        height = 348;
//                        legacy =                         {
//                        };
//                        rank = 0;
//                        subType = watch308;
//                        subtype = watch308;
//                        type = image;
//                        url = "images/2016/02/11/us/women-president-callout/women-president-callout-watch308.jpg";
//                        width = 312;
//                    },
//                                        {
//                        caption = "<null>";
//                        credit = "<null>";
//                        "crop_name" = smallSquare168;
//                        height = 168;
//                        legacy =                         {
//                        };
//                        rank = 0;
//                        subType = smallSquare168;
//                        subtype = smallSquare168;
//                        type = image;
//                        url = "images/2016/02/11/us/women-president-callout/women-president-callout-smallSquare168.jpg";
//                        width = 168;
//                    }
//                );
//                "news_desk" = "U.S.";
//                "pub_date" = "2016-02-12T17:20:31+0000";
//                "section_name" = "U.S.";
//                snippet = "A generation gap is emerging over the importance of electing a woman to the White House. We invite you to share your opinion. The Times may follow up with you.";
//                source = "The New York Times";
//                "type_of_material" = "Interactive Feature";
//                uri = "nyt://interactive/06c1330f-77d4-5b0e-827b-64e01c817b97";
//                "web_url" = "https://www.nytimes.com/interactive/2016/02/11/us/woman-president-callout.html";
//                "word_count" = 0;
//            }
//        );
//        meta =         {
//            hits = 15392579;
//            offset = 0;
//            time = 2022;
//        };
//    };
//    status = OK;
//}
