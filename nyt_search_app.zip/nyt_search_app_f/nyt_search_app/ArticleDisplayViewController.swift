//
//  ArticleDisplayViewController.swift
//  nyt_search_app
//
//  Created by Michelle on 30/6/2020.
//  Copyright © 2020 michellekeoy. All rights reserved.
//

import UIKit
import SafariServices

class ArticleDisplayViewController: UIViewController {
    
    var headline: UILabel!
    var snippet: UITextView!
    var link: UIButton!
    var linklabel: UILabel!
    var image: UIImageView!
    var headlinetext : String
    var snippettext : String
    var linktext: String
    var imagetext: UIImage?

    
    init(headlinetext: String, snippettext: String, linktext: String, imagetext: UIImage?) {

        self.headlinetext = headlinetext
        self.snippettext = snippettext
        self.linktext = linktext
        self.imagetext = imagetext
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        
        title = "The New York Times"
        view.backgroundColor = .white
        
        headline = UILabel()
        headline.backgroundColor = .white
        headline.font = UIFont(name: "TimesNewRomanPS-BoldMT", size: 30)
        headline.translatesAutoresizingMaskIntoConstraints = false
        headline.text = headlinetext
        headline.adjustsFontSizeToFitWidth = true
        headline.numberOfLines = 2
        view.addSubview(headline)
        
        snippet =  UITextView()
        snippet.backgroundColor = .white
        snippet.font = UIFont(name: "TimesNewRomanPSMT", size: 20)
        snippet.translatesAutoresizingMaskIntoConstraints = false
        snippet.text = snippettext
        view.addSubview(snippet)
        
        linklabel = UILabel()
        linklabel.translatesAutoresizingMaskIntoConstraints = false
        linklabel.text = "Click link below for full article:"
        linklabel.font = UIFont(name: "TimesNewRomanPS-BoldMT", size: 18)
        view.addSubview(linklabel)
        
        link = UIButton()
        link.setTitle(linktext, for: .normal)
        link.setTitleColor(.black, for: .normal)
        link.translatesAutoresizingMaskIntoConstraints = false
        link.addTarget(self, action: #selector(goToWebsite), for: .touchUpInside)
        view.addSubview(link)
        
        image = UIImageView()
        image.contentMode = .scaleAspectFill
        image.layer.masksToBounds = true
        image.image = imagetext
        image.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(image)

        setUpConstraints()
    }
    
    @objc func goToWebsite(){
        if let unwrappedLinktitle = link.titleLabel?.text{
            present(SFSafariViewController(url: URL(string: unwrappedLinktitle)!), animated: true, completion: nil)
        }
    }
    
    func setUpConstraints(){
        NSLayoutConstraint.activate([
            headline.topAnchor.constraint(equalTo: view.topAnchor, constant: 20),
            headline.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            headline.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            headline.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            headline.bottomAnchor.constraint(equalTo: headline.topAnchor, constant: 80)
            
        ])
        NSLayoutConstraint.activate([
            image.topAnchor.constraint(equalTo: headline.bottomAnchor),
            image.leadingAnchor.constraint(equalTo: headline.leadingAnchor),
            image.trailingAnchor.constraint(equalTo: headline.trailingAnchor),
            image.bottomAnchor.constraint(equalTo: image.topAnchor, constant: 480)
              ])
        NSLayoutConstraint.activate([
            snippet.topAnchor.constraint(equalTo: image.bottomAnchor, constant: 10),
            snippet.leadingAnchor.constraint(equalTo: image.leadingAnchor),
            snippet.trailingAnchor.constraint(equalTo: image.trailingAnchor),
            snippet.bottomAnchor.constraint(equalTo: snippet.topAnchor, constant: 150)

              ])
        NSLayoutConstraint.activate([
            linklabel.topAnchor.constraint(equalTo: snippet.bottomAnchor, constant: 10),
            linklabel.leadingAnchor.constraint(equalTo: snippet.leadingAnchor)])

        NSLayoutConstraint.activate([
            link.topAnchor.constraint(equalTo: linklabel.bottomAnchor),
            link.leadingAnchor.constraint(equalTo: snippet.leadingAnchor),
            link.trailingAnchor.constraint(equalTo: snippet.trailingAnchor),
              ])
    }
    
    }
    




