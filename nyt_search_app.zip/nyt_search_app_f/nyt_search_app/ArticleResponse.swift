//
//  ArticleResponse.swift
//  nyt_search_app
//
//  Created by Michelle on 30/6/2020.
//  Copyright © 2020 michellekeoy. All rights reserved.
//


import Foundation

import UIKit

class articleClass{
    var headline: String
    var snippet: String
    var link: String
    var imageName: UIImage?


init(headline: String, snippet: String, link: String, imageName: UIImage?) {
    self.headline = headline
    self.snippet = snippet
    self.link = link
    self.imageName = imageName
    }
}

struct Headline : Codable{
    var main: String
}

struct Multimedia: Codable{
    var url: String
}

struct Article: Codable{
    var headline: Headline
    var multimedia: [Multimedia]
    var snippet: String
    var web_url: String
    }


struct docs : Codable {
    var docs: [Article]
}

struct Response: Codable {
    var response: docs
}


