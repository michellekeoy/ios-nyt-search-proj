//
//  NetworkManager.swift
//  nyt_search_app
//
//  Created by Michelle on 30/6/2020.
//  Copyright © 2020 michellekeoy. All rights reserved.
//

import Foundation
import Alamofire

enum DataResponse<T: Any>{
    case success(data: T)
    case failure(error: Error)
}

let endpoint = "https://api.nytimes.com/svc/search/v2/articlesearch.json"

class NetworkManager {
    
    static func getArticle(apikey: String, keyword: String, completion: @escaping (([articleClass]) -> Void)){
        let parameterdictionary: [String: Any] = [
            "api-key" : apikey,
            "q" : keyword
        ]
        AF.request(endpoint, method: .get, parameters: parameterdictionary).validate().responseData { (response) in
            switch response.result {
            case .success(let data):
                let jsonDecoder = JSONDecoder()
                if let articleData = try? jsonDecoder.decode(Response.self, from: data){
                    let partofarticle = articleData.response.docs
                    var articleArray : [articleClass] = []
                    for articleindex in partofarticle{
                        if articleindex.multimedia.isEmpty{
                          let newArticle = articleClass(headline: articleindex.headline.main, snippet: articleindex.snippet, link: articleindex.web_url, imageName: nil)
                            articleArray.append(newArticle)
                            if articleArray.count == partofarticle.count {
                                completion(articleArray)
                            }
                        } else {
                        fetchImage(imageURL: ("https://static01.nyt.com/"+articleindex.multimedia[0].url)){ image in
                            let newArticle = articleClass(headline: articleindex.headline.main, snippet: articleindex.snippet, link: articleindex.web_url, imageName: image)
                            articleArray.append(newArticle)
                            if articleArray.count == partofarticle.count {
                                completion(articleArray)
                            }
                        }
                    }
                }
                }
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
    static func fetchImage(imageURL: String, completion: @escaping ((UIImage) -> Void)){
        AF.request(imageURL, method: .get).validate().responseData{ (response) in
            switch response.result {
            case .success(let data):
                if let image = UIImage(data: data) {
                    completion(image)
                }
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
        
    }
}
