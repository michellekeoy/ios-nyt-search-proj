//
//  ArticleCollectionViewCell.swift
//  nyt_search_app
//
//  Created by Michelle on 30/6/2020.
//  Copyright © 2020 michellekeoy. All rights reserved.
//

import UIKit

class ArticleCollectionViewCell: UICollectionViewCell {
    
    var articleLabel: UILabel!
    var articleImage: UIImageView!
    let padding: CGFloat = 14
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        articleLabel = UILabel()
        articleLabel.backgroundColor = .white
        articleLabel.numberOfLines = 3
        articleLabel.textColor = .black
        articleLabel.font = UIFont(name: "TimesNewRomanPSMT", size: 28)
        articleLabel.textAlignment = NSTextAlignment.left
        articleLabel.translatesAutoresizingMaskIntoConstraints = false
        articleLabel.adjustsFontSizeToFitWidth = true
        articleLabel.preferredMaxLayoutWidth = 50
        contentView.addSubview(articleLabel)
        
        
        articleImage = UIImageView()
        articleImage.contentMode = .scaleAspectFit
        articleImage.layer.masksToBounds = true
        articleImage.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(articleImage)
        
        setUpConstraints()
}
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
}
    func setUpConstraints(){
       
        NSLayoutConstraint.activate([
            articleLabel.topAnchor.constraint(equalTo: contentView.topAnchor),
            articleLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            articleLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
            articleLabel.centerXAnchor.constraint(equalTo: contentView.centerXAnchor),
        ])
       NSLayoutConstraint.activate([
            articleImage.topAnchor.constraint(equalTo: articleLabel.bottomAnchor),
            articleImage.centerXAnchor.constraint(equalTo: articleLabel.centerXAnchor),
            articleImage.leadingAnchor.constraint(equalTo: articleLabel.leadingAnchor),
            articleImage.trailingAnchor.constraint(equalTo: articleLabel.trailingAnchor),
            articleImage.bottomAnchor.constraint(equalTo: articleImage.topAnchor, constant: 320)
        ])
            
    }
    
    func configure2(article: articleClass) {
        articleLabel.text = article.headline
        articleImage.image = article.imageName
    }
}
