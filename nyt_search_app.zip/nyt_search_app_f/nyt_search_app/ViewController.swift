//
//  ViewController.swift
//  nyt_search_app
//
//  Created by Michelle on 30/6/2020.
//  Copyright © 2020 michellekeoy. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var ArticleCollectionView: UICollectionView!
    var ArticleList : [articleClass] = []
    var searchBar : UISearchBar!
    var keyword: String = ""
    
    let articleCellReuseIdentifier = "articleReuseIdentifier"
    let APIkey = "M84JwQTUSkj3FzfeDa913IWxYhW60Y1L"
    
    // Constants for constraints
    let padding: CGFloat = 14
    let headerHeight: CGFloat = 50

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        title = "The New York Times"
        view.backgroundColor = .white
        // Can I make the font NY Times font?
        
        // Set up ArticleCollectionView
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        layout.minimumInteritemSpacing = 20
        layout.minimumLineSpacing = padding
        
        ArticleCollectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        ArticleCollectionView.register(ArticleCollectionViewCell.self, forCellWithReuseIdentifier: articleCellReuseIdentifier)
        ArticleCollectionView.dataSource = self
        ArticleCollectionView.translatesAutoresizingMaskIntoConstraints = false
        ArticleCollectionView.delegate = self
        ArticleCollectionView.backgroundColor = .white
        view.addSubview(ArticleCollectionView)
        
        searchBar = UISearchBar()
        searchBar.translatesAutoresizingMaskIntoConstraints = false
        searchBar.showsCancelButton = true
        searchBar.placeholder = "Enter Keyword for Articles"
        searchBar.delegate = self
        view.addSubview(searchBar)
       
        // Add Articles to ArticleList
        ArticleList = []
        
        setupConstraints()
    }
    func getArticles(){
        NetworkManager.getArticle(apikey: APIkey, keyword: keyword) { articleArray in
                self.ArticleList = articleArray
                DispatchQueue.main.async {
                self.ArticleCollectionView.reloadData()
            }
        }
        
    }
    func setupConstraints() {
    NSLayoutConstraint.activate([
        searchBar.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
        searchBar.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: padding),
        searchBar.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -padding)
        ])
        
    NSLayoutConstraint.activate([
        ArticleCollectionView.topAnchor.constraint(equalTo: searchBar.bottomAnchor),
        ArticleCollectionView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: padding),
        ArticleCollectionView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
        ArticleCollectionView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -padding)
    ])
    }
    
}

extension ViewController: UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier:
        articleCellReuseIdentifier, for: indexPath) as! ArticleCollectionViewCell
        cell.configure2(article: ArticleList[indexPath.item])
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return ArticleList.count
    }

}

extension ViewController: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath){
        
        if collectionView == ArticleCollectionView {
            let selectedArticle = ArticleList[indexPath.item]
            let vc = ArticleDisplayViewController(headlinetext: selectedArticle.headline, snippettext: selectedArticle.snippet, linktext: selectedArticle.link, imagetext: selectedArticle.imageName)

            present(vc, animated: true)
        }
}
}
extension ViewController: UICollectionViewDelegateFlowLayout {

func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
    
    let size = (collectionView.frame.width - 2*padding)
    return CGSize(width: size, height: size)
        
    }
    
}

extension ViewController: UISearchBarDelegate{

    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        self.keyword = searchBar.text!
        getArticles()
    }

    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.text = ""
    }
}

