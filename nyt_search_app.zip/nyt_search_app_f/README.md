# ios-nyt-search-app

This is an application created using XCode for an Introduction to iOS Development course, using language Swift.
It is a New York Times app that allows the user to search for NYT articles, using the NY Times API to retrieve articles to implement search functionality. This can filter out keywords using string matches.

To use, user should have XCode. Open the nyt_search_app.xcworkspace file and not the nyt_search_app.xcodeproj file, and run.
